---
layout: page
title: Contact Thi
css: ["contact.css"]
comment: 1
---

You can contact me at [{{site.user.email}}](mailto:{{site.user.email}}).

PS. If you have time, welcome to [my site](https://dinhanhthi.com).
